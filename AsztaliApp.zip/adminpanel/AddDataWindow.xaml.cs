using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Windows;
using System.Windows.Controls;

namespace AuthApp
{
    public partial class AddDataWindow : Window
    {
        private string selectedTable;
        private readonly List<string> nonIdColumnNames = new List<string>();
        private readonly List<TextBox> textBoxes = new List<TextBox>();
        private DataGrid dataGrid;
        private StackPanel panel;

        public AddDataWindow(string tableName, MySqlDataReader reader)
        {
            InitializeComponent();
            selectedTable = tableName;
            panel = new StackPanel();

            while (reader.Read())
            {
                string columnName = reader.GetString(0);
                // M�dos�tott felt�tel: ha az oszlopn�v nem tartalmazza az "id" sz�t
                if (!columnName.ToLower().Contains("id"))
                {
                    nonIdColumnNames.Add(columnName);
                    Label label = new Label { Content = columnName };
                    TextBox textBox = new TextBox();
                    textBoxes.Add(textBox);
                    panel.Children.Add(label);
                    panel.Children.Add(textBox);
                }
            }
            reader.Close();

            Button submitButton = new Button { Content = "Hozz�ad�s" };
            submitButton.Click += SubmitButton_Click;
            panel.Children.Add(submitButton);

            dataGrid = new DataGrid { Margin = new Thickness(10) };
            panel.Children.Add(new Label { Content = "T�bl�zat tartalma:" });
            panel.Children.Add(dataGrid);

            this.Content = panel;
            RefreshDataGrid();
        }

        private void SubmitButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                using (MySqlConnection conn = new MySqlConnection("Server=localhost;Database=auto_adatbazis;Uid=root;Pwd=root;"))
                {
                    conn.Open();
                    string columnList = string.Join(", ", nonIdColumnNames);
                    string paramList = string.Join(", ", nonIdColumnNames.ConvertAll(name => $"@{name}"));
                    string query = $"INSERT INTO {selectedTable} ({columnList}) VALUES ({paramList})";

                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    for (int i = 0; i < nonIdColumnNames.Count; i++)
                    {
                        cmd.Parameters.AddWithValue($"@{nonIdColumnNames[i]}", textBoxes[i].Text);
                    }
                    cmd.ExecuteNonQuery();

                    MessageBox.Show("Adat sikeresen hozz�adva!");

                    foreach (var tb in textBoxes)
                    {
                        tb.Text = "";
                    }

                    RefreshDataGrid();
                }

                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hiba t�rt�nt: " + ex.ToString());
            }
        }

        private void RefreshDataGrid()
        {
            try
            {
                using (MySqlConnection conn = new MySqlConnection("Server=localhost;Database=auto_adatbazis;Uid=root;Pwd=root;"))
                {
                    conn.Open();
                    string selectQuery = $"SELECT * FROM {selectedTable}";
                    MySqlDataAdapter adapter = new MySqlDataAdapter(selectQuery, conn);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    dataGrid.ItemsSource = dt.DefaultView;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hiba t�rt�nt a t�bl�zat friss�t�sekor: " + ex.ToString());
            }
        }
    }
}